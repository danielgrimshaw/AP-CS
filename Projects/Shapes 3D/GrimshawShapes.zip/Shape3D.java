public interface Shape3D {
   public double getVolume();
   public double getSurfaceArea();
}